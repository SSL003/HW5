//Sajjad Salimi 40223041

#include <stdio.h>

int main()
{
    int n;
    printf("Enter a number\n");
    scanf("%d", &n);
    printf("Enter %d characters without spaces\n", n);
    char list[n];
    scanf("%s", &list);
  for (int i = 0; i < n/2; i++)
  {
    for (int j = 0; j < n; j++)
    {
        if(list[j]==list[j+1])
        {
            for (int k = j+2; k < n; k++)
            {
                list[k-2]=list[k];
                list[k-1]='\0';
            }
            printf("%s\n",list);
        }
    }
  } 
  return 0;
}